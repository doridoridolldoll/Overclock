<template>

    <section id="hero" class="d-flex align-items-center justify-content-center">
    <div class="container" data-aos="fade-up">

      <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="150">
        <div class="col-xl-6 col-lg-8">
          <h1>Powerful Digital Hardware With OverClock<span>.</span></h1>
          <h2>우리는 최고의 상품을 최적의 가격에 판매합니다</h2>
        </div>
      </div>

      <div class="row gy-4 mt-5 justify-content-center" data-aos="zoom-in" data-aos-delay="250">
        <div class="col-xl-2 col-md-4">
          <div class="icon-box">
            <i class="bi bi-mouse2"></i>
            <h3><a href="">MOUSE</a></h3>
          </div>
        </div>
        <div class="col-xl-2 col-md-4">
          <div class="icon-box">
            <i class="bi bi-keyboard"></i>
            <h3><a href="">KEYBOARD</a></h3>
          </div>
        </div>
        <div class="col-xl-2 col-md-4">
          <div class="icon-box">
            <i class="bi bi-headset"></i>
            <h3><a href="">HEADSET</a></h3>
          </div>
        </div>
        <div class="col-xl-2 col-md-4">
          <div class="icon-box">
            <i class="bi bi-display"></i>
            <h3><a href="">DISPLAY</a></h3>
          </div>
        </div>
        <div class="col-xl-2 col-md-4">
          <div class="icon-box">
            <i class="bi bi-pc-display"></i>
            <h3><a href="">etc</a></h3>
          </div>
        </div>
      </div>

    </div>
  </section><!-- End Hero -->

  <main id="main">



    

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <p>GPU</p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTmUHH0v9f2o86r8JPMrnRhY6V_Si8AT_ldqmyq4TxxTsNdXMHIsqqrDmA_R48ZbxSHCz2iSWqCvvrXhCHhSDNIYZAQ1RO0i0Jhn2Mw5dN7NG4Rm4RVnuIJ&usqp=CAE" style="width:292px;height:200px;"></div>
              <br><br><br><br><br>
              <h3><a href="" style="width:292px;" >rtx 3080 ti</a></h3>
              <span><h4>최저가 보증! 전국 최저가</h4></span>
              <span><h5>판매가 4,800,000원</h5></span>
              <span><h5>할인가 4,300,000원</h5></span>
            </div>
           
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcSTXvtin5mUI2Ck-YFCTRcsBfvfWIbekiKQIs3999L_lRQV0bF4bn_yhMhBSxvuLs7JPIj4rdqY-xLfvscc_reFSrIi1olwXmNoaJ5a7wAVt8jWQu16azb8&usqp=CAE" style="width:292px; height:200px;"></div>
              <br><br><br><br><br>
              <h2><a href="">rtx 3090 ti</a></h2>
              <span><h4>현존 최고 사양 그래픽카드</h4></span>
              <span><h5>판매가 5,800,000원</h5></span>
              <span><h5>할인가 5,300,000원</h5></span>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTTz-q-rvITAUKm5kBl4ba4BJxs3u6uNHBYvXOXA3b-Qwx8RdYKDANffP5Tws-G7pFpbWF6Zw0i1uh2XZvS2qkGG89E6k4IiDPKIYWjmBfSPDSX4nUDsJ-RzQ&usqp=CAE" style="width:292px; height:200px;"></div>
              <br><br><br><br><br>
              <h2><a href="">rtx 3070</a></h2>
              <span><h4>가성비로 쓰기 좋은 그래픽카드</h4></span>
              <span><h5>판매가 3,800,000원</h5></span>
              <span><h5>할인가 3,300,000원</h5></span>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTmUHH0v9f2o86r8JPMrnRhY6V_Si8AT_ldqmyq4TxxTsNdXMHIsqqrDmA_R48ZbxSHCz2iSWqCvvrXhCHhSDNIYZAQ1RO0i0Jhn2Mw5dN7NG4Rm4RVnuIJ&usqp=CAE" style="width:292px;height:200px;"></div>
              <br><br><br><br><br>
              <h3><a href="" style="width:292px;">rtx 3080 ti</a></h3>
              <span><h4>최저가 보증! 전국 최저가</h4></span>
              <span><h5>판매가 4,800,000원</h5></span>
              <span><h5>할인가 4,300,000원</h5></span>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcSTXvtin5mUI2Ck-YFCTRcsBfvfWIbekiKQIs3999L_lRQV0bF4bn_yhMhBSxvuLs7JPIj4rdqY-xLfvscc_reFSrIi1olwXmNoaJ5a7wAVt8jWQu16azb8&usqp=CAE" style="width:292px; height:200px;"></div>
              <br><br><br><br><br>
              <h2><a href="">rtx 3090 ti</a></h2>
              <span><h4>현존 최고 사양 그래픽카드</h4></span>
              <span><h5>판매가 5,800,000원</h5></span>
              <span><h5>할인가 5,300,000원</h5></span>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTTz-q-rvITAUKm5kBl4ba4BJxs3u6uNHBYvXOXA3b-Qwx8RdYKDANffP5Tws-G7pFpbWF6Zw0i1uh2XZvS2qkGG89E6k4IiDPKIYWjmBfSPDSX4nUDsJ-RzQ&usqp=CAE" style="width:292px; height:200px;"></div>
              <br><br><br><br><br>
              <h2><a href="">rtx 3070</a></h2>
              <span><h4>가성비로 쓰기 좋은 그래픽카드</h4></span>
              <span><h5>판매가 3,800,000원</h5></span>
              <span><h5>할인가 3,300,000원</h5></span>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTmUHH0v9f2o86r8JPMrnRhY6V_Si8AT_ldqmyq4TxxTsNdXMHIsqqrDmA_R48ZbxSHCz2iSWqCvvrXhCHhSDNIYZAQ1RO0i0Jhn2Mw5dN7NG4Rm4RVnuIJ&usqp=CAE" style="width:292px;height:200px;"></div>
              <br><br><br><br><br>
              <h3><a href="" style="width:292px;">rtx 3080 ti</a></h3>
              <span><h4>최저가 보증! 전국 최저가</h4></span>
              <span><h5>판매가 4,800,000원</h5></span>
              <span><h5>할인가 4,300,000원</h5></span>
            </div>
           
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcSTXvtin5mUI2Ck-YFCTRcsBfvfWIbekiKQIs3999L_lRQV0bF4bn_yhMhBSxvuLs7JPIj4rdqY-xLfvscc_reFSrIi1olwXmNoaJ5a7wAVt8jWQu16azb8&usqp=CAE" style="width:292px; height:200px;"></div>
              <br><br><br><br><br>
              <h2><a href="">rtx 3090 ti</a></h2>
              <span><h4>현존 최고 사양 그래픽카드</h4></span>
              <span><h5>판매가 5,800,000원</h5></span>
              <span><h5>할인가 5,300,000원</h5></span>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTTz-q-rvITAUKm5kBl4ba4BJxs3u6uNHBYvXOXA3b-Qwx8RdYKDANffP5Tws-G7pFpbWF6Zw0i1uh2XZvS2qkGG89E6k4IiDPKIYWjmBfSPDSX4nUDsJ-RzQ&usqp=CAE" style="width:292px; height:200px;"></div>
              <br><br><br><br><br>
              <h2><a href="">rtx 3070</a></h2>
              <span><h4>가성비로 쓰기 좋은 그래픽카드</h4></span>
              <span><h5>판매가 3,800,000원</h5></span>
              <span><h5>할인가 3,300,000원</h5></span>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTmUHH0v9f2o86r8JPMrnRhY6V_Si8AT_ldqmyq4TxxTsNdXMHIsqqrDmA_R48ZbxSHCz2iSWqCvvrXhCHhSDNIYZAQ1RO0i0Jhn2Mw5dN7NG4Rm4RVnuIJ&usqp=CAE" style="width:292px;height:200px;"></div>
              <br><br><br><br><br>
              <h3><a href="" style="width:292px;">rtx 3080 ti</a></h3>
              <span><h4>최저가 보증! 전국 최저가</h4></span>
              <span><h5>판매가 4,800,000원</h5></span>
              <span><h5>할인가 4,300,000원</h5></span>
            </div>
           
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcSTXvtin5mUI2Ck-YFCTRcsBfvfWIbekiKQIs3999L_lRQV0bF4bn_yhMhBSxvuLs7JPIj4rdqY-xLfvscc_reFSrIi1olwXmNoaJ5a7wAVt8jWQu16azb8&usqp=CAE" style="width:292px; height:200px;"></div>
              <br><br><br><br><br>
              <h2><a href="">rtx 3090 ti</a></h2>
              <span><h4>현존 최고 사양 그래픽카드</h4></span>
              <span><h5>판매가 5,800,000원</h5></span>
              <span><h5>할인가 5,300,000원</h5></span>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTTz-q-rvITAUKm5kBl4ba4BJxs3u6uNHBYvXOXA3b-Qwx8RdYKDANffP5Tws-G7pFpbWF6Zw0i1uh2XZvS2qkGG89E6k4IiDPKIYWjmBfSPDSX4nUDsJ-RzQ&usqp=CAE" style="width:292px; height:200px;"></div>
              <br><br><br><br><br>
              <h2><a href="">rtx 3070</a></h2>
              <span><h4>가성비로 쓰기 좋은 그래픽카드</h4></span>
              <span><h5>판매가 3,800,000원</h5></span>
              <span><h5>할인가 3,300,000원</h5></span>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->
  </main><!-- End #main -->


  
</template>

<script>
import { ref } from '@vue/reactivity'
export default {
    name:'ToPeri',
  setup(){
    const title = ref('Peri')

    return {title}
  }


}
</script>

<style>
</style>