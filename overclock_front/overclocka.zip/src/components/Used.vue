<template>
<div>
<section id="hero" class="d-flex align-items-center justify-content-center">
    <div class="container" data-aos="fade-up">

      <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="150">
        <div class="col-xl-6 col-lg-8">
          <h1>Powerful Digital Hardware With OverClock<span>.</span></h1>
          <h2>우리는 최고의 상품을 최적의 가격에 판매합니다</h2>
        </div>
      </div>

    </div>
  </section><!-- End Hero -->

  <main id="main">



    

    <section class="ftco-section ftco-cart">
			<div class="container">
				<div class="row">
    			<div class="col-md-12 ftco-animate">
    				<div class="cart-list">
	    				<table class="table">
						    <thead class="thead-primary">
						      <tr class="text-center">
                    <th>글 번호</th>
						        <th>사진</th>
						        <th>제목</th>
						        <th>시간</th>
						        <th>조회수</th>
						      </tr>
						    </thead>
						    <tbody>
						      <tr class="text-center">
						        <td class ="price"> 1 </td>
						        
						        <td class="image-prod"><div class="img" style="background-image:url(./assets/img/portfolio/portfolio-3.jpg);"></div></td>
						      
						        <td class="product-name">
						        	<h3>Bell Pepper</h3>
						        </td>
				            <td class="price">2022/09/02</td>
						        <td class="price"> 2 </td>
					
						      </tr><!-- END TR-->

                  <tr class="text-center">
						        <td class ="price"> 2 </td>
						        
						        <td class="image-prod"><div class="img" style="background-image:url(images/product-1.jpg);"></div></td>
						      
						        <td class="product-name">
						        	<h3>Bell Pepper</h3>
						        </td>
				            <td class="price">2022/09/02</td>
						        <td class="price"> 1 </td>
					
						      </tr><!-- END TR-->

                  <tr class="text-center">
						        <td class ="price"> 3 </td>
						        
						        <td class="image-prod"><div class="img" style="background-image:url(images/product-1.jpg);"></div></td>
						      
						        <td class="product-name">
						        	<h3>Bell Pepper</h3>
						        </td>
				            <td class="price">2022/09/02</td>
						        <td class="price"> 1 </td>
					
						      </tr><!-- END TR-->

                  <tr class="text-center">
						        <td class ="price"> 4 </td>
						        
						        <td class="image-prod"><div class="img" style="background-image:url(images/product-1.jpg);"></div></td>
						      
						        <td class="product-name">
						        	<h3>Bell Pepper</h3>
						        </td>
				            <td class="price">2022/09/02</td>
						        <td class="price"> 1 </td>
					
						      </tr><!-- END TR-->

                  <tr class="text-center">
						        <td class ="price"> 5 </td>
						        
						        <td class="image-prod"><div class="img" style="background-image:url(images/product-1.jpg);"></div></td>
						      
						        <td class="product-name">
						        	<h3>Bell Pepper</h3>
						        </td>
				            <td class="price">2022/09/02</td>
						        <td class="price"> 1 </td>
					
						      </tr><!-- END TR-->

                  <tr class="text-center">
						        <td class ="price"> 6 </td>
						        
						        <td class="image-prod"><div class="img" style="background-image:url(images/product-1.jpg);"></div></td>
						      
						        <td class="product-name">
						        	<h3>Bell Pepper</h3>
						        </td>
				            <td class="price">2022/09/02</td>
						        <td class="price"> 1 </td>
					
						      </tr><!-- END TR-->

                  <tr class="text-center">
						        <td class ="price"> 7 </td>
						        
						        <td class="image-prod"><div class="img" style="background-image:url(images/product-1.jpg);"></div></td>
						      
						        <td class="product-name">
						        	<h3>Bell Pepper</h3>
						        </td>
				            <td class="price">2022/09/02</td>
						        <td class="price"> 1 </td>
					
						      </tr><!-- END TR-->

						    
						    </tbody>
						  </table>
					  </div>
    			</div>
    		</div>
			</div>
		</section>
</main>
</div>
</template>

<script>
export default {
    name:'ToUsed',

}
</script>

<style>

</style>